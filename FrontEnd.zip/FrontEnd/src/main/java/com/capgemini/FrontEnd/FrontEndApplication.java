package com.capgemini.FrontEnd;

import java.io.File;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.FrontEnd.controller.FrontController;




@SpringBootApplication
public class FrontEndApplication {

	public static void main(String[] args)throws IOException {
		new File(FrontController.uploadingdir).mkdirs();
		SpringApplication.run(FrontEndApplication.class, args);
}
}