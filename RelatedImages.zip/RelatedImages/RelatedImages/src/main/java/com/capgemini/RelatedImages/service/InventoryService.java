package com.capgemini.RelatedImages.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RelatedImages.dao.IInventoryDao;
import com.capgemini.RelatedImages.model.Inventory;

@Service("inventoryService")
@Transactional
public class InventoryService implements IInventoryService {

	@Autowired
	private IInventoryDao inventoryDao;
	
	@Override
	public List<Inventory> getAll() {
		
		return inventoryDao.findAll();
	}

}
