package com.capgemini.RelatedImages.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.RelatedImages.model.Inventory;
import com.capgemini.RelatedImages.model.ProductImage;
import com.capgemini.RelatedImages.service.IImageService;
import com.capgemini.RelatedImages.service.IInventoryService;

@Controller
public class MyController {

	public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";
    public static final String productname = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname";
    public static final String productid = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname/productid";
    public static final String imageid = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname/productid/imageid/";
    
	@Autowired
	private IImageService imageService;
	
	@Autowired
	private IInventoryService inventoryService;
	
	@RequestMapping("/")
	public String uploadImagePage(ModelMap map)
	{
		List<Inventory> products=inventoryService.getAll();
		map.put("products", products);
		System.out.println("Sharath");
		return "relatedImage";
	}
	
	@RequestMapping("/upload")
	public String uploadImage(@RequestParam("uploadingFiles") MultipartFile uploadingFiles,
    		@RequestParam("selectedProduct")Integer productId) throws IOException
	{
		System.out.println(productId);
		int imgName=0;
	      //  for(MultipartFile uploadedFile : uploadingFiles) {
	            File file = new File(imageid + uploadingFiles.getOriginalFilename());
	            uploadingFiles.transferTo(file);
	           
	            ProductImage product=new ProductImage();

	            
	            String path=file.getPath();
	            
	            String extenstion= path.substring(path.lastIndexOf('.'), path.length());
	            
	            //product.setImgUrl("../uploadingdir/" +imgName+".jpg");
	            
	           // imageService.save(product);
	            
	            System.out.println(extenstion);
	            Integer imageId=imageService.findMaxImageId();
	            if(imageId!=null)
	            	imgName=imageId+1;
	            else
	            	imgName=0;
	            File file2=new File(imageid+imgName+ extenstion);
	            file.renameTo(file2);
	            
	            product.setImgUrl("../imageid/" +imgName+ extenstion);
	            System.out.println(product.getImgUrl());
	            product.setProductId(productId);
	            product.setPriority(false);
	          /*  
	            ProductImage image=imageService.getById(productId);
	            if(image!=null)
	            {
	            	product.setPriority(false);
	            }
	            else
	            {
	            	product.setPriority(true);
	            }*/
	            
	            System.out.println("GoodMorning");
	            imageService.save(product);
	        //}
		
		return "redirect:/show";
	}
	
	/*@RequestMapping("/upload")
	public void uploadImage(@ModelAttribute("image"))*/
	
	@RequestMapping("/show")
    public String showProducts(ModelMap map) {
    	
    	List<ProductImage> products= imageService.getAll();
    	map.put("products", products);
    	return "show";
    }
	
}
